/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dados;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.util.JSON;

/**
 *
 * @author filipe
 */
public class DAO {
    private DBCollection collection;
    DAO(){
        conn();
    }
    public void conn(){
        MongoClient mongoClient = new MongoClient("localhost", 27017);
        DB db = mongoClient.getDB("limpo");
        collection = db.getCollection("user");
    }
    public String find(String json){
        DBObject find = (DBObject) JSON.parse(json);
        DBCursor cursorDoc = collection.find(find);
        DBObject doc = cursorDoc.next();
        return doc.toString();
    }
}
