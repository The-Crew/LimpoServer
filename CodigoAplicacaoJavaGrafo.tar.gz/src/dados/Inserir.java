/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dados;

import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.HashSet;
import model.Aresta;
import model.Faxineira;
import model.Usuario;


/**
 *
 * @author filipe
 */
public class Inserir {
    private HashSet<String> visitados = new HashSet<String>();
    
    public ArrayList<Aresta> dados(String id, ArrayList<Aresta> arestas){
        Gson gson = new Gson();
        Buscar buscar = new Buscar();
        String json = buscar.id(id);
        Usuario user = new Usuario();
        user = gson.fromJson(json, Usuario.class);
        if(!this.visitados.contains(id)){
            this.visitados.add(id);
        }
        
        for(Object i : user.getIndic()){
            Aresta aresta = new Aresta();
            Usuario user2 = new Usuario();
            Convert idUser2 = new Convert();
            idUser2 = gson.fromJson(i.toString(), Convert.class) ;
            user2.setId(idUser2.getAnt());
            aresta.setUser2(user2);
            aresta.setUser1(user);
            Faxineira faxineira = new Faxineira();
            faxineira = gson.fromJson(i.toString(), Faxineira.class);
            faxineira = gson.fromJson(buscar.id(faxineira.getId()), Faxineira.class);
            aresta.setFaxineira(faxineira);
            arestas.add(aresta);
            if(!"sys".equals(user2.getId())){
                if(!this.visitados.contains(user2.getId())){
                    dados(user2.getId(), arestas);
                    this.visitados.add(user2.getId());
                }
            }
        }
        if(user.getIndicados() != null){
        for(Object i : user.getIndicados()){
            Aresta aresta = new Aresta();
            Usuario user2 = new Usuario();
            Convert idUser2 = new Convert();
            idUser2 = gson.fromJson(i.toString(), Convert.class) ;
            user2.setId(idUser2.getPre());
            aresta.setUser2(user2);
            aresta.setUser1(user);
            Faxineira faxineira = new Faxineira();
            faxineira = gson.fromJson(i.toString(), Faxineira.class);
            faxineira = gson.fromJson(buscar.id(faxineira.getId()), Faxineira.class);
            aresta.setFaxineira(faxineira);
            arestas.add(aresta);
            if(!"sys".equals(user2.getId())){
                if(!this.visitados.contains(user2.getId())){
                    dados(user2.getId(), arestas);
                    this.visitados.add(user2.getId());
                }
            }
        }
        }
        
        
        
        for(int i= 0; i < arestas.size(); i++){
            //System.out.println(arestas.get(i).getUser1().getId()+", "+arestas.get(i).getFaxineira().getId()+", "+arestas.get(i).getUser2().getId());
        }
        
        return arestas;
    }
}
