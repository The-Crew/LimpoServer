/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dados;

import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.util.JSON;
import java.util.Set;

/**
 *
 * @author filipe
 */
public class Buscar {
    public static DAO database;
    Buscar(){
        if(database == null){
            database = new DAO();
        }
    }
    public String id(String id){
        
        id = "{'id':'"+id+"'}";
        return database.find(id);
    }
}
