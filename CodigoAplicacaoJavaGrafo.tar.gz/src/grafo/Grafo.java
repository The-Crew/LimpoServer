/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grafo;

import model.Aresta;
import control.DFS;
import dados.Inserir;
import java.util.ArrayList;

/**
 *
 * @author filipe
 */
public class Grafo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //String dados = "id=c4&[&s=f3:3&c3=f1:4&c3=f2:5&]&[[&c5=f3:3&]]";
        Inserir inserir = new Inserir();
        ArrayList <Aresta> arestas = new ArrayList< >();
        arestas = inserir.dados("c5", arestas);
        //System.out.println(arestas.get(0).getFaxineira().getQualificacao()+", "+arestas.get(4).getFaxineira().getQualificacao()+", "+arestas.get(7).getFaxineira().getQualificacao());
        
        DFS dft = new DFS();
        dft.setArestas(arestas);
        dft.executar(arestas.get(0).getUser1());
        //System.out.println("Melhor: "+dft.getMelhor().getId()+" - Qualificação: "+dft.getMelhor().getQualificacao());
        System.out.print(dft.getMelhor().getId());
    }
    
}
