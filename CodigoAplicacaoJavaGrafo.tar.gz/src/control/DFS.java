/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import model.Aresta;
import model.Faxineira;
import model.Usuario;

/**
 *
 * @author filipe
 */
public class DFS {
    private List<Aresta> arestas;
    private Map<Usuario, Usuario> predecessores;
    private Set<Usuario> visitados;
    private Faxineira melhor;

    public void setArestas(List<Aresta> _arestas){
        arestas = _arestas;
    }
    public void executar(Usuario inicial){
        predecessores = new HashMap<Usuario, Usuario>();
        visitados = new HashSet<Usuario>();
        if(inicial == null){
            return;
        }
        dfs_rec(inicial, null);
    }
    private void dfs_rec(Usuario usuario, Usuario predecessor){
        predecessores.put(usuario, predecessor);
        visitados.add(usuario);
        
        for(Usuario u : getVizinhos(usuario)){
            if(!visitados.contains(u)){
                if(!u.getId().equals("sys")){
                    //System.out.println("Buscar: "+u.getId());
                    dfs_rec(u, usuario);
                }
            }
        }
    }
    private List<Usuario> getVizinhos(Usuario usuario){
        List<Usuario> vizinhos = new ArrayList<Usuario>();
        for(Aresta aresta : arestas){
            if(aresta.getUser1().getId().equals(usuario.getId())){
                if(melhor == null || melhor.getQualificacao() < aresta.getFaxineira().getQualificacao()){
                    melhor = aresta.getFaxineira();
                } else {
                }
                vizinhos.add(aresta.getUser2());
                //System.out.println("Vizionho dee "+usuario.getId()+": "+aresta.getUser2().getId());
            }else if(aresta.getUser2().getId().equals(usuario.getId())){
                vizinhos.add(aresta.getUser1());
                //System.out.println("Vizionho de "+usuario.getId()+": "+aresta.getUser1().getId());
            }
        }
        return vizinhos;
    }

    public Faxineira getMelhor() {
        return melhor;
    }
    
}
