/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author filipe
 */
public class Usuario {
    private String id;
    private Object[] indic;
    private Object[] indicados;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Object[] getIndic() {
        return indic;
    }

    public void setIndic(Object[] indic) {
        this.indic = indic;
    }

    public Object[] getIndicados() {
        return indicados;
    }

    public void setIndicados(Object[] indicados) {
        this.indicados = indicados;
    }

    @Override
    public String toString() {
        return "Usuario{" + "id=" + id + ", indic=" + indic + ", indicados=" + indicados + '}';
    }
    
}
