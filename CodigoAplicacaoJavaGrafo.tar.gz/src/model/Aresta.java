/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author filipe
 */
public class Aresta {
    private Usuario user1;
    private Usuario user2;
    private Faxineira faxineira;

    public Usuario getUser1() {
        return user1;
    }

    public void setUser1(Usuario u1) {
        this.user1 = u1;
    }

    public Usuario getUser2() {
        return user2;
    }

    public void setUser2(Usuario u2) {
        this.user2 = u2;
    }

    public Faxineira getFaxineira() {
        return faxineira;
    }

    public void setFaxineira(Faxineira faxineira) {
        this.faxineira = faxineira;
    }
}
